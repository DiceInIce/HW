﻿#include <iostream>

using namespace std;

int main()
{
	cout << "Every" << endl;
	cout << "\tHunter" << endl;
	cout << "\t\tWants" << endl;
	cout << "\t\t\tTo know" << endl;
	cout << "\t\t\t\tWhere" << endl;
	cout << "\t\t\t\t\tDoes Pheasant" << endl;
	cout << "\t\t\t\t\t\tSit" << endl;

	return 0;
}