#include <iostream>

using namespace std;

int main() {
	cout << "Can't sit around holding up my guard" << endl;
	cout << "Let it all go, let it all..." << endl;
	cout << "(Go around, going in and face the inevitable)" << endl;
	cout << "Can't figure out how to play my part" << endl;
	cout << "Where do I go? How do I..." << endl;
	cout << "(Go around, go in and make it inhabitable)" << endl;

	return 0;
}